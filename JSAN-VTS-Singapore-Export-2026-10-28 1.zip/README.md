# JSAN VTS - Singapore export

Pulled from the VTS API itself (`/api/locations/session/<id>/export-kml` and
`export-kml-cleaned`), so these are byte-for-byte what the admin panel's own export buttons
produce - not a reconstruction.

Generated 28 October 2026. Project: Singapore.

## Contents

| Path | What it is |
|---|---|
| `sessions-raw-gps/*.kml` | **Raw GPS, one file per trip** (49 files) - every stored fix, unsnapped. |
| `sessions-cleaned/*.kml` | **Cleaned / road-snapped track, one file per trip** (46 files). |
| `polygons-shapefile/` | Scope polygons as an **ESRI shapefile** (.shp/.shx/.dbf/.prj/.cpg), WGS84. |
| `sessions-index.csv` | One row per trip: session id, driver, date, hours, GPS km, UKM, and the two filenames. |
| `session-data-full.csv` | The full 28-column session export. |

Filenames are `S<nn>_<date>_<time>_<driver>` with a `_RAW` or `_CLEANED` suffix, so the two
folders line up one-to-one and sort chronologically.

## Shapefile attributes

`name`, `status` (CLOSED/open), `closed_on`, `area_km2`, `road_km`, `cover_pct`, `drivers`, `gf_id`.

Outer rings are wound clockwise per the shapefile spec, and `.cpg` declares UTF-8 so non-ASCII
area names survive the import.

## Notes

- Raw GPS is already filtered once on the device before upload: fixes worse than 100 m accuracy
  dropped, jumps over 60 m/s dropped, 1 fix per 30 s while stationary. "Raw" here means
  un-snapped, not unprocessed.
- Coverage is measured from the cleaned track plus the accurate raw fixes, never the raw line
  alone - which is why a raw track can wander off a road without that road turning blue.
- Odometer figures in the session CSV are unreliable (some rows hold trip distance rather than the
  dashboard reading). Use GPS km.
